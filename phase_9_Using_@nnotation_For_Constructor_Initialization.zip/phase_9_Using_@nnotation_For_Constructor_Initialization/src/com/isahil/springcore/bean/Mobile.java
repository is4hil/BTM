package com.isahil.springcore.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Mobile implements Serializable {
	
	
	//@Value(value="3000000")
	private int price;
	private String brand;
	private double weight;
	private String color;
	private int dimensions;
	// private Battery battery;

	public Mobile() {
		System.out.println(this.getClass().getSimpleName() + " Created  using default constructor");
	}
	
	
	
	
	@Autowired
	public Mobile(@Value(value="30")int price, @Value(value="ABC")String brand, @Value(value="30")double weight, @Value(value="blue")String color, @Value(value="30")int dimensions) {
		super();
		System.out.println(this.getClass().getSimpleName() + " Created  using param constructor");
		this.price = price;
		this.brand = brand;
		this.weight = weight;
		this.color = color;
		this.dimensions = dimensions;
	}





	public int getPrice() {
		return price;
	}
	
	//@Value(value="8888")
	public void setPrice(int price) {
		this.price = price;
	}

	public String getBrand() {
		return brand;
	}

	//@Value(value="Nokia")
	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getWeight() {
		return weight;
	}

	@Value(value="250")
	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getColor() {
		return color;
	}

	//@Value(value="Red")
	public void setColor(String color) {
		this.color = color;
	}

	public int getDimensions() {
		return dimensions;
	}

	//@Value(value="300")
	public void setDimensions(int dimensions) {
		this.dimensions = dimensions;
	}

	@Override
	public String toString() {
		return "Mobile [price=" + price + ", brand=" + brand + ", weight=" + weight + ", color=" + color
				+ ", dimensions=" + dimensions + "]";
	}
	
	
}
