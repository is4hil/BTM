package com.isahil.springcore.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.isahil.springcore.bean.Mobile;

public class AppTester {
	public static void main(String[] args) {

		ApplicationContext container = new ClassPathXmlApplicationContext("context.xml");
		Mobile mobile = container.getBean(Mobile.class);
		System.out.println(mobile);
	}
} 
