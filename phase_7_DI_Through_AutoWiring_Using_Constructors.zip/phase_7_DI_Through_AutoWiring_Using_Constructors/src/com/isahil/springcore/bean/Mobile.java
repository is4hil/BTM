package com.isahil.springcore.bean;

import java.io.Serializable;

/**
 * @author SAITAN
 *
 */
public class Mobile implements Serializable {
	private int price;
	private String brand;
	private double weight;
	private String color;
	private int dimensions;
	private Battery battery;

	public Mobile() {
		System.out.println(this.getClass().getSimpleName() + " Created  using default constructor");
	}

	public Mobile(int price, String brand, double weight, String color, int dimensions, Battery battery) {
		super();
		System.out.println(this.getClass().getSimpleName() + " Created using parameterized constructor");
		this.price = price;
		this.brand = brand;
		this.weight = weight;
		this.color = color;
		this.dimensions = dimensions;
		this.battery = battery;
		System.out.println("Value initialized using Param Constructor of Mobile");
		System.out.println(price+brand+weight+color+battery);
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		System.err.println("Calling Setter methods of Mobile");
		this.price = price;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getDimensions() {
		return dimensions;
	}

	public void setDimensions(int dimensions) {
		this.dimensions = dimensions;
	}

	public Battery getBattery() {
		return battery;
	}

	public void setBattery(Battery battery) {
		this.battery = battery;
	}

	public void call() {
		System.out.println("Calling Person");
	}

	public void sendSms() {
		System.out.println("Sending Messages");
	}

	public void chargeMobile() {
		System.out.println("Battery low.Charge d Battery calling--> battery.charge();");
		battery.charge();
	}

	@Override
	public String toString() {
		return "Mobile [price=" + price + ", brand=" + brand + ", weight=" + weight + ", color=" + color
				+ ", dimensions=" + dimensions + ", battery=" + battery + "]";
	}

}
