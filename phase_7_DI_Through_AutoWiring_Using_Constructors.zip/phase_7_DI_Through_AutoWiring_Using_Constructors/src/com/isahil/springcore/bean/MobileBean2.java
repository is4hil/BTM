package com.isahil.springcore.bean;

public class MobileBean2 {
	public MobileBean2() {
		System.out.println(this.getClass().getSimpleName()+" created---Default Constructor");
		}
}
