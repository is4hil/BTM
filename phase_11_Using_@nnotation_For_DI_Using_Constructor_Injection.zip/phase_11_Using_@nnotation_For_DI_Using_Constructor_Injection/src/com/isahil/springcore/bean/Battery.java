package com.isahil.springcore.bean;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Battery implements Serializable {
	private int capacity;
	private double size;
	private String model;

	
	public Battery() {
		System.out.println(this.getClass().getSimpleName()+" created---Default Constructor");
	}
	
	@Autowired
	public Battery(@Value(value="300")int capacity,@Value(value="28")double size,@Value(value="SamsungBttry") String model) {
		super();
		System.out.println(this.getClass().getSimpleName()+" created----Parameterized Constructor is called");
		this.capacity = capacity;
		this.size = size;
		this.model = model;
	}

	public int getCapacity() {
		return capacity;
	}

	
	//@Value(value="2000")
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	
	public double getSize() {
		return size;
	}

	//@Value(value="56.00")
	public void setSize(double size) {
		this.size = size;
	}

	public String getModel() {
		return model;
	}

	//@Value(value="branded bttry")
	public void setModel(String model) {
		this.model = model;
	}

	public void charge() {
		System.out.println("Battery is charging");
	}

	@Override
	public String toString() {
		return "Battery [capacity=" + capacity + ", size=" + size + ", model=" + model + "]";
	}
	
	
	
	
}
