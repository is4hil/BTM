package com.isahil.springcore.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.isahil.springcore.bean.Mobile;

public class AppTester {
	public static void main(String[] args) {
		ApplicationContext container =new ClassPathXmlApplicationContext("context.xml");
		Mobile mob=container.getBean(Mobile.class);
		mob.call();
		mob.sendSms();
	}
} 
