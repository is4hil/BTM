package com.isahil.springcore.bean;

import java.io.Serializable;

public class Mobile implements Serializable {
	private int price;
	private String brand;
	private double weight;
	private String color;
	private int dimensions;

	public Mobile() {
		System.out.println(this.getClass().getSimpleName()+" created");
	}
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getDimensions() {
		return dimensions;
	}

	public void setDimensions(int dimensions) {
		this.dimensions = dimensions;
	}

	public void call() {
		System.out.println("Calling Person");
	}

	public void sendSms() {
		System.out.println("Sending Messages");
	}
}
