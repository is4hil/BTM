package com.isahil.springcore.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.isahil.springcore.bean.Mobile;

public class AppTester {
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		ApplicationContext container = new ClassPathXmlApplicationContext("context.xml");
		Mobile mob = container.getBean(Mobile.class);
		mob.call();
		mob.sendSms();
		mob.chargeMobile();
		System.out.println(mob);
		
	}
}
/*
 * Calling Person 
 * Sending Messages 
 * Batter low.Charge Battery 
 * Battery is charging
 * Mobile [price=10000, brand=Apple, weight=156.0, color=Gold, dimensions=0, battery=Battery [capacity=10000, size=34.56, model=BLC5]]
 */