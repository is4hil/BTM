package com.isahil.springcore.bean;

import java.io.Serializable;

public class Battery implements Serializable {
	private int capacity;
	private double size;
	private String model;

	public Battery() {
	System.out.println(this.getClass().getSimpleName()+ "Created using default Constructor");	
	}
	
	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void charge() {
		System.out.println("Battery is charging");
	}

	@Override
	public String toString() {
		return "Battery [capacity=" + capacity + ", size=" + size + ", model=" + model + "]";
	}
	
	
}
