package com.isahil.springcore.bean;

import java.io.Serializable;

public class Mobile implements Serializable {
	private int price;
	private String brand;
	private double weight;
	private String color;
	private int dimensions;
	private Battery battery;

	public Mobile() {
		System.out.println(this.getClass().getSimpleName() +"created using Default Constructor");
	}
	

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getDimensions() {
		return dimensions;
	}

	public void setDimensions(int dimensions) {
		this.dimensions = dimensions;
	}

	public Battery getBattery() {
		return battery;
	}

	public void setBattery(Battery battery) {
		this.battery = battery;
	}

	public void call() {
		System.out.println("Calling Person");
	}

	public void sendSms() {
		System.out.println("Sending Messages");
	}

	public void chargeMobile() {
		System.out.println("Batter low.Charge Battery");
		battery.charge();
	}

	@Override
	public String toString() {
		return "Mobile [price=" + price + ", brand=" + brand + ", weight=" + weight + ", color=" + color
				+ ", dimensions=" + dimensions + ", battery=" + battery + "]";
	}

	

	

}
